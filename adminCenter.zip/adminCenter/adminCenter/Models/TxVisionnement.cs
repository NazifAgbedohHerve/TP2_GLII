﻿namespace adminCenter.Models
{
    public class TxVisionnement
    {
        public int Numero { get; set; }
        public ModeAcces ModeAcces { get; set; }

        public void ConsulterHistoriquePourUnRealisateur(object realisateur) { }
    }
}