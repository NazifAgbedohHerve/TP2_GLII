﻿namespace adminCenter.Models
{
    public class Administrateur : Utilisateur
    {
        public int Numéro { get; set; }
    }
}