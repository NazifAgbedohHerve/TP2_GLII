﻿namespace adminCenter.Models
{
    public class Utilisateur
    {
        public int Numéro { get; set; }
        public string NomUsager { get; set; } = "";
        public string MotDePasse { get; set; } = "";
    }
}