﻿namespace adminCenter.Models
{
    public class Personne
    {
        public int Numéro { get; set; }
        public string Nom { get; set; } = "";
        public string Pays { get; set; } = "";
        public TypePersonne TypePersonne { get; set; }
    }
}