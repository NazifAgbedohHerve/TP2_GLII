﻿namespace adminCenter.Models
{
    public class LanguePiste
    {
        public int Code { get; set; }
        public TypePiste Type { get; set; }
    }
}