﻿namespace adminCenter.Models
{
    public enum TypePersonne
    {
        Physique,
        Morale
    }

    public enum TypeRôle
    {
        Acteur,
        Réalisateur,
        Producteur,
        MaisonProduction
    }

    public enum StatutDisponible
    {
        Disponible,
        Retire,
        Prochainement
    }

    public enum TypePiste
    {
        Audio,
        SousTitre
    }

    public enum ModeAcces
    {
        Abonnement,
        A_L_Unite
    }
}