﻿namespace adminCenter.Models
{
    public class Session
    {
        public int Numero { get; set; }
        public DateTime DateConnexion { get; set; }
        public DateTime DateDeconnexion { get; set; }

        // Méthodes simulées
        public void DemanderFormInscriptionMembre() { }
        public void AfficherFormInscriptionMembre() { }
        public void ConfirmerInscriptionMembre(Membre membre) { }
        public void DemanderFormInscriptionAdmin() { }
        public void AfficherFormInscriptionAdmin() { }
        public void ConfirmerInscriptionAdmin(Administrateur admin) { }
        public void DemanderFormOuvertureSession() { }
        public void AfficherFormOuvertureSession() { }
        public void ValiderInfoConnexion(string identifiant, string motDePasse) { }
        public void AfficherMessageConnexionRéussie() { }
        public void AfficherMessageÉchecConnexion() { }
        public void DemanderFormulaireRechercheFilms() { }
        public void AfficherFormulaireRechercheFilms() { }
        public void RechercherFilms(string critères) { }
        public void AfficherFilms(Film[] films) { }
        public Film? SelectionnerFilm() => null;
        public void AfficherDescriptionFilm(Film film) { }
        public void VisionnerFilm(Film film) { }
        public void VisualiserDataStreaming(object dataStream) { }
        public void ConsulterHistoriqueTransactions(object client) { }
        public void AfficherTransactions(Transaction[] transactions) { }
    }
}