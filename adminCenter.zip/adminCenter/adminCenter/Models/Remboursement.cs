﻿using System;

namespace adminCenter.Models
{
    public class Remboursement
    {
        public int Numero { get; set; }
        public DateTime Date { get; set; }
        public double Prix { get; set; }
        public double MontantTaxe { get; set; }
        public string Nom { get; set; } = "";
        public string Prenom { get; set; } = "";
        public string Email { get; set; } = "";
        public string Motif { get; set; } = "";
        public string Statut { get; set; } = "En attente";

        public double Total => Prix + MontantTaxe;
    }
}