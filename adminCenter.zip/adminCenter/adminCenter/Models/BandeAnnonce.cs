﻿namespace adminCenter.Models
{
    public class BandeAnnonce
    {
        public int Numero { get; set; }
        public int Duree { get; set; }
        public string Bande { get; set; } = "";
    }
}