﻿namespace adminCenter.Models
{
    public class Categorie
    {
        public int Numero { get; set; }
        public string Nom { get; set; } = "";
    }
}