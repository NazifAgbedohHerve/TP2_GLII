﻿namespace adminCenter.Models
{
    public class AbonnementPlan
    {
        public int Numero { get; set; }
        public string Nom { get; set; } = "";
        public double PrixMensuel { get; set; }
        public int LimiteAppareils { get; set; }
    }
}