﻿namespace adminCenter.Models
{
    public class Visiteur : Utilisateur
    {
        public string Nom { get; set; } = "";
        public string Prénom { get; set; } = "";
        public string Adresse { get; set; } = "";
        public string Téléphone { get; set; } = "";
        public string AdresseCourriel { get; set; } = "";
        public bool AAcceptéRecevoirNotifications { get; set; }
        public string LanguePréférée { get; set; } = "";

        // Méthodes
        public Membre? ValiderInfoConnexion(string identifiant, string motDePasse)
        {
            // Simulation logique d’authentification
            return null;
        }
    }
}