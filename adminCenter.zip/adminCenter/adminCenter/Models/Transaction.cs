﻿namespace adminCenter.Models
{
    public class Transaction
    {
        public int Numero { get; set; }
        public DateTime Date { get; set; }
        public double Prix { get; set; }
        public double MontantTaxe { get; set; }

        // Méthode
        public Transaction[] ConsulterHistorique(Membre membre) => Array.Empty<Transaction>();
    }
}