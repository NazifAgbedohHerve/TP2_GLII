﻿namespace adminCenter.Models;

public class TxRemboursement : Transaction
{
    
}