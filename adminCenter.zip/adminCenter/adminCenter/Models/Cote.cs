﻿namespace adminCenter.Models
{
    public class Cote
    {
        public int CoteValeur { get; set; }
        public string Commentaire { get; set; } = "";
    }
}