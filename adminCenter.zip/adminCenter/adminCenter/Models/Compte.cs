﻿namespace adminCenter.Models
{
    public class Compte
    {
        public int Numero { get; set; }
        public double Solde { get; set; }
    }
}