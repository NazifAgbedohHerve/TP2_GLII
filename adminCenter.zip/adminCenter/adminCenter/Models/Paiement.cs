﻿namespace adminCenter.Models
{
    public class Paiement
    {
        public int Numero { get; set; }
        public DateTime Date { get; set; }
        public double Montant { get; set; }
    }
}