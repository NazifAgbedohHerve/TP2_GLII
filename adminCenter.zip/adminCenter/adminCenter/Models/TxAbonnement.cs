﻿namespace adminCenter.Models
{
    public class TxAbonnement
    {
        public DateTime ValideDepuis { get; set; }
        public DateTime ValideJusqua { get; set; }
        public bool RenouvellementAuto { get; set; }
    }
}