﻿namespace adminCenter.Models
{
    public class Membre : Visiteur
    {
        public int Numero { get; set; }
        public string Titre { get; set; } = "";
        public int AnneeSortie { get; set; }
        public int Duree { get; set; }
        public double Prix { get; set; }
        public string Synopsis { get; set; } = "";
        public StatutDisponible Statut { get; set; }
        public string MotsCles { get; set; } = "";

        public void Rechercher(string criteres) { }
        public object Visionner() => null;
    }
}