﻿namespace adminCenter.Models
{
    public class CarteCredit
    {
        public string NumeroCarteCrédit { get; set; } = "";
        public string Titulaire { get; set; } = "";
        public DateTime DateExpiration { get; set; }
    }
}