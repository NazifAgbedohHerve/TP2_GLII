﻿namespace adminCenter.Models
{
    public class Film
    {
        public int Numero { get; set; }
        public string Titre { get; set; } = "";
        public int AnneeSortie { get; set; }
        public int Duree { get; set; }
        public double Prix { get; set; }
        public string Synopsis { get; set; } = "";
        public StatutDisponible Statut { get; set; }
        public string MotsCles { get; set; } = "";
        public BandeAnnonce BandeAnnonce { get; set; } = new BandeAnnonce();
        public List<CreditFilm> Credits { get; set; } = new();
        public List<Cote> Cotes { get; set; } = new();

        // Méthodes
        public void Rechercher(string criteres) { }
        public object? Visionner() => null; // placeholder DataStream
    }
}