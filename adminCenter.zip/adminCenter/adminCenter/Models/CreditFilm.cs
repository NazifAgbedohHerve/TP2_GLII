﻿namespace adminCenter.Models
{
    public class CreditFilm
    {
        public Personne Personne { get; set; } = new Personne();
        public TypeRôle Role { get; set; }
    }
}