﻿using System.Windows;
using System.Windows.Controls;

namespace adminCenter.Views
{
    public partial class AdminDashboard : Window
    {
        public AdminDashboard()
        {
            InitializeComponent();
        }

        private void BtnFilm_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new FilmsView(); // affichera la page Film
        }

        private void BtnPlan_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new PlanAbonnementView();
        }

        private void BtnFiche_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new ChiffresView();
        }

        private void BtnRemboursement_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new RemboursementsView();
        }

        private void BtnParametre_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new ParametreView();
        }
    }

    internal class ParametreView
    {
    }
    
    
}