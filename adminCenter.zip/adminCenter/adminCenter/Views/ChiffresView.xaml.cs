﻿using System.Collections.Generic;
using System.Windows.Controls;
using LiveCharts;
using LiveCharts.Wpf;

namespace adminCenter.Views
{
    public partial class ChiffresView : UserControl
    {
        // 🔹 Indicateurs principaux
        public int TotalFilms { get; set; } = 138;
        public int MembresActifs { get; set; } = 5230;
        public double RevenusMensuels { get; set; } = 19642.80;
        public int TotalVisionnements { get; set; } = 91234;

        // 🔹 Nouveaux indicateurs financiers
        public double RevenusTotaux { get; set; } = 124578.90;
        public double RevenusAbonnements { get; set; } = 84500.50;
        public double RevenusPaiementActe { get; set; } = 40078.40;

        // 🔹 Graphique
        public SeriesCollection RevenusParMois { get; set; }
        public List<string> MoisLabels { get; set; }

        // 🔹 Liste des films populaires
        public List<FilmStat> TopFilms { get; set; }

        public ChiffresView()
        {
            InitializeComponent();

            // Données simulées pour le graphique
            RevenusParMois = new SeriesCollection
            {
                new ColumnSeries
                {
                    Title = "Revenus ($)",
                    Values = new ChartValues<double> { 12500, 14800, 15200, 16500, 18900, 19642 }
                }
            };

            MoisLabels = new List<string> { "Janv", "Févr", "Mars", "Avr", "Mai", "Juin" };

            // Données simulées pour les films populaires
            TopFilms = new List<FilmStat>
            {
                new FilmStat { Rang = "1️⃣", Titre = "Inception", Vues = 1432 },
                new FilmStat { Rang = "2️⃣", Titre = "Interstellar", Vues = 1321 },
                new FilmStat { Rang = "3️⃣", Titre = "Avatar 2", Vues = 1204 },
                new FilmStat { Rang = "4️⃣", Titre = "Tenet", Vues = 1139 },
                new FilmStat { Rang = "5️⃣", Titre = "The Batman", Vues = 1094 },
            };

            DataContext = this;
        }

        public class FilmStat
        {
            public string Rang { get; set; }
            public string Titre { get; set; }
            public int Vues { get; set; }
        }
    }
}
