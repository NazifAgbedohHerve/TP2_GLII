﻿using System.Windows;
using System.Windows.Controls;
using adminCenter.Models;

namespace adminCenter.Views
{
    public partial class AddPlanAbonnementView : UserControl
    {
        public AddPlanAbonnementView()
        {
            InitializeComponent();
        }

        // 🔙 Bouton retour
        private void BtnRetour_Click(object sender, RoutedEventArgs e)
        {
            var dashboard = Window.GetWindow(this) as AdminDashboard;
            if (dashboard != null)
                dashboard.MainContent.Content = new PlanAbonnementView();
        }

        // ❌ Annuler
        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            BtnRetour_Click(sender, e);
        }

        // 💾 Ajouter
        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            // Simulation d’ajout
            string nom = NomTextBox.Text;
            double.TryParse(PrixTextBox.Text, out double prix);
            int.TryParse(LimiteTextBox.Text, out int limite);

            if (string.IsNullOrWhiteSpace(nom))
            {
                MessageBox.Show("Veuillez saisir un nom de plan.", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            MessageBox.Show($"✅ Plan ajouté :\n\nNom : {nom}\nPrix : {prix:C}\nLimite appareils : {limite}",
                "Succès",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            // Retour automatique à la liste après ajout
            BtnRetour_Click(sender, e);
        }
    }
}