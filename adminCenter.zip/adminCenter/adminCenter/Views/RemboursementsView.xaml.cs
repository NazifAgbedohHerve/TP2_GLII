﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using adminCenter.Models;

namespace adminCenter.Views
{
    public partial class RemboursementsView : UserControl
    {
        private List<Remboursement> _remboursements;
        private Remboursement? _selected;

        public RemboursementsView()
        {
            InitializeComponent();
            LoadFakeData();
            RefundsGrid.ItemsSource = _remboursements;
        }

        private void LoadFakeData()
        {
            _remboursements = new List<Remboursement>
            {
                new Remboursement { Numero = 1, Date = new DateTime(2025,11,1), Prix = 19.99, MontantTaxe = 2, Nom="Dupont", Prenom="Alice", Email="alice@ex.com", Motif="Problème technique" },
                new Remboursement { Numero = 2, Date = new DateTime(2025,11,2), Prix = 9.99, MontantTaxe = 1, Nom="Tremblay", Prenom="Marc", Email="marc@ex.com", Motif="Erreur de facturation" },
                new Remboursement { Numero = 3, Date = new DateTime(2025,11,3), Prix = 14.99, MontantTaxe = 1.5, Nom="Nguyen", Prenom="Sarah", Email="sarah@ex.com", Motif="Abonnement non voulu" }
            };
        }

        private void BtnDetail_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as Button)?.DataContext is Remboursement r)
            {
                _selected = r;
                NomText.Text = r.Nom;
                PrenomText.Text = r.Prenom;
                EmailText.Text = r.Email;
                MotifText.Text = r.Motif;
                DetailPanel.Visibility = Visibility.Visible;
            }
        }

        private void BtnApprouver_Click(object sender, RoutedEventArgs e)
        {
            if (_selected != null)
            {
                _selected.Statut = "✅ Approuvé";
                RefundsGrid.Items.Refresh();
                DetailPanel.Visibility = Visibility.Collapsed;

                MessageBox.Show($"Le remboursement #{_selected.Numero} a été approuvé.", "Succès",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void BtnRefuser_Click(object sender, RoutedEventArgs e)
        {
            if (_selected != null)
            {
                _selected.Statut = "❌ Refusé";
                RefundsGrid.Items.Refresh();
                DetailPanel.Visibility = Visibility.Collapsed;

                MessageBox.Show($"Le remboursement #{_selected.Numero} a été refusé.", "Refusé",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnRetour_Click(object sender, RoutedEventArgs e)
        {
            DetailPanel.Visibility = Visibility.Collapsed;
        }
    }
}
