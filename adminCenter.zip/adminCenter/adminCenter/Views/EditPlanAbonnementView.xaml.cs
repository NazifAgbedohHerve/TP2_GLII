﻿using System.Windows;
using System.Windows.Controls;
using adminCenter.Models;

namespace adminCenter.Views
{
    public partial class EditPlanAbonnementView : UserControl
    {
        private readonly AbonnementPlan _plan;

        // ✅ Constructeur qui reçoit un plan
        public EditPlanAbonnementView(AbonnementPlan plan)
        {
            InitializeComponent();
            _plan = plan;

            // Préremplissage
            NomTextBox.Text = _plan.Nom;
            PrixTextBox.Text = _plan.PrixMensuel.ToString("F2");
            LimiteTextBox.Text = _plan.LimiteAppareils.ToString();
        }

        private void BtnRetour_Click(object sender, RoutedEventArgs e)
        {
            var dashboard = Window.GetWindow(this) as AdminDashboard;
            if (dashboard != null)
                dashboard.MainContent.Content = new PlanAbonnementView();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            BtnRetour_Click(sender, e);
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            // Simulation de sauvegarde
            _plan.Nom = NomTextBox.Text;
            double.TryParse(PrixTextBox.Text, out double prix);
            int.TryParse(LimiteTextBox.Text, out int limite);

            _plan.PrixMensuel = prix;
            _plan.LimiteAppareils = limite;

            MessageBox.Show($"✅ Modifications enregistrées :\n\n{_plan.Nom} - {prix:C} / {limite} appareils",
                "Succès",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            BtnRetour_Click(sender, e);
        }
    }
}