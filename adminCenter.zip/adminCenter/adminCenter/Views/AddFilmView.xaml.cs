﻿using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;

namespace adminCenter.Views
{
    public partial class AddFilmView : UserControl
    {
        public AddFilmView()
        {
            InitializeComponent();
        }

        private void BtnBrowse_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Filter = "Fichiers vidéo (*.mp4;*.avi;*.mov)|*.mp4;*.avi;*.mov|Tous les fichiers|*.*"
            };

            if (dialog.ShowDialog() == true)
                txtBandeAnnonce.Text = dialog.FileName;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("✅ Nouveau film ajouté (simulation)", "Succès",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            // Même effet que retour
            BtnRetour_Click(sender, e);
        }

        private void BtnRetour_Click(object sender, RoutedEventArgs e)
        {
            var dashboard = Window.GetWindow(this) as AdminDashboard;
            if (dashboard != null)
            {
                // Retour vers la vue Films
                dashboard.MainContent.Content = new FilmsView();
            }
        }
    }
}