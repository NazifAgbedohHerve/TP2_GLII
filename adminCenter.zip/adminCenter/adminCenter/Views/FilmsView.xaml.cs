﻿using System.Windows;
using System.Windows.Controls;
using adminCenter.Models;

namespace adminCenter.Views
{
    public partial class FilmsView : UserControl
    {
        public FilmsView()
        {
            InitializeComponent();
        }

        // 👉 Quand on clique sur Détails
        private void BtnDetail_Click(object sender, RoutedEventArgs e)
        {
            // Récupère le film de la ligne sélectionnée
            if ((sender as Button)?.DataContext is Film selectedFilm)
            {
                // Cherche la fenêtre AdminDashboard
                var dashboard = Window.GetWindow(this) as AdminDashboard;
                if (dashboard != null)
                {
                    // Charge la vue détail à la place du tableau
                    dashboard.MainContent.Content = new FilmDetailView(selectedFilm);
                }
            }
        }
        
        private void BtnAddFilm_Click(object sender, RoutedEventArgs e)
        {
            // Récupère la fenêtre principale
            var dashboard = Window.GetWindow(this) as AdminDashboard;
            if (dashboard != null)
            {
                // Charge le UserControl AddFilmView dans la zone principale
                dashboard.MainContent.Content = new AddFilmView();
            }
        }
        
        
        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as Button)?.DataContext is Film selectedFilm)
            {
                var dashboard = Window.GetWindow(this) as AdminDashboard;
                if (dashboard != null)
                {
                    // On passe le film sélectionné à EditFilmView
                    dashboard.MainContent.Content = new EditFilmView();
                    // 💡 plus tard : tu pourras passer l'objet selectedFilm au constructeur pour pré-remplir les champs
                }
            }
        }
        
        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as Button)?.DataContext is Film selectedFilm)
            {
                // Boîte de confirmation
                var result = MessageBox.Show(
                    $"Voulez-vous vraiment supprimer le film « {selectedFilm.Titre} » ?",
                    "Confirmation de suppression",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (result == MessageBoxResult.Yes)
                {
                    // Ici tu pourras ajouter ta logique réelle de suppression (ex : BDD)
                    MessageBox.Show($"Le film « {selectedFilm.Titre} » a été supprimé avec succès ✅",
                        "Suppression confirmée",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                }
            }
        }

    }
}