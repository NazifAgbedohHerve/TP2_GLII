﻿using System.Windows;
using System.Windows.Controls;
using adminCenter.Models;

namespace adminCenter.Views
{
    public partial class PlanAbonnementView : UserControl
    {
        public PlanAbonnementView()
        {
            InitializeComponent();
        }

        private void BtnAddPlan_Click(object sender, RoutedEventArgs e)
        {
            var dashboard = Window.GetWindow(this) as AdminDashboard;
            if (dashboard != null)
                dashboard.MainContent.Content = new AddPlanAbonnementView();
        }

        private void BtnDetail_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as Button)?.DataContext is AbonnementPlan selectedPlan)
            {
                var dashboard = Window.GetWindow(this) as AdminDashboard;
                if (dashboard != null)
                    dashboard.MainContent.Content = new PlanAbonnementDetailView(selectedPlan);
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as Button)?.DataContext is AbonnementPlan selectedPlan)
            {
                var dashboard = Window.GetWindow(this) as AdminDashboard;
                if (dashboard != null)
                    dashboard.MainContent.Content = new EditPlanAbonnementView(selectedPlan);
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as Button)?.DataContext is AbonnementPlan selectedPlan)
            {
                var result = MessageBox.Show(
                    $"Voulez-vous vraiment supprimer le plan « {selectedPlan.Nom} » ?",
                    "Confirmation de suppression",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (result == MessageBoxResult.Yes)
                {
                    MessageBox.Show($"✅ Plan supprimé : {selectedPlan.Nom}",
                        "Suppression réussie", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
        }
    }
}
