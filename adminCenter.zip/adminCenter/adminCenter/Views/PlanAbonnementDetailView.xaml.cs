﻿using System.Windows;
using System.Windows.Controls;
using adminCenter.Models;

namespace adminCenter.Views
{
    public partial class PlanAbonnementDetailView : UserControl
    {
        private readonly AbonnementPlan _plan;

        public PlanAbonnementDetailView(AbonnementPlan plan)
        {
            InitializeComponent();
            _plan = plan;

            // Exemple d’affichage
            TitreTextBlock.Text = $"Détails du plan : {plan.Nom}";
            PrixTextBlock.Text = $"Prix mensuel : {plan.PrixMensuel:C}";
            LimiteTextBlock.Text = $"Limite d’appareils : {plan.LimiteAppareils}";
        }

        private void BtnRetour_Click(object sender, RoutedEventArgs e)
        {
            var dashboard = Window.GetWindow(this) as AdminDashboard;
            if (dashboard != null)
                dashboard.MainContent.Content = new PlanAbonnementView();
        }
    }
}