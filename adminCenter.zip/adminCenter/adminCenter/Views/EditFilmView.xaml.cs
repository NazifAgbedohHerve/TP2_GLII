﻿using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using adminCenter.Models;

namespace adminCenter.Views
{
    public partial class EditFilmView : UserControl
    {
        private readonly Film _film;

        // 🔹 Constructeur qui reçoit le film sélectionné
        public EditFilmView(Film film = null)
        {
            InitializeComponent();

            _film = film;

            // Si un film est passé, on pré-remplit les champs
            if (_film != null)
            {
                TitreTextBox.Text = _film.Titre;
                AnneeTextBox.Text = _film.AnneeSortie.ToString();
                DureeTextBox.Text = _film.Duree.ToString();
                PrixTextBox.Text = _film.Prix.ToString();
                SynopsisTextBox.Text = _film.Synopsis;
                // txtBandeAnnonce.Text = _film.BandeAnnonce ?? "";
            }
        }

        private void BtnBrowse_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Filter = "Fichiers vidéo (*.mp4;*.avi;*.mov)|*.mp4;*.avi;*.mov|Tous les fichiers|*.*"
            };

            if (dialog.ShowDialog() == true)
                txtBandeAnnonce.Text = dialog.FileName;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            // 🔹 Si tu veux mettre à jour les données du film
            if (_film != null)
            {
                _film.Titre = TitreTextBox.Text;
                _film.AnneeSortie = int.TryParse(AnneeTextBox.Text, out int annee) ? annee : 0;
                _film.Duree = int.TryParse(DureeTextBox.Text, out int duree) ? duree : 0;
                _film.Prix = double.TryParse(PrixTextBox.Text, out double prix) ? prix : 0;
                _film.Synopsis = SynopsisTextBox.Text;
               // _film.BandeAnnoncePath = txtBandeAnnonce.Text;
            }

            MessageBox.Show("✅ Modifications enregistrées (simulation)", 
                            "Succès", 
                            MessageBoxButton.OK, 
                            MessageBoxImage.Information);

            // 🔙 Retour à la liste des films après sauvegarde
            BtnRetour_Click(sender, e);
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            BtnRetour_Click(sender, e);
        }

        private void BtnRetour_Click(object sender, RoutedEventArgs e)
        {
            var dashboard = Window.GetWindow(this) as AdminDashboard;
            if (dashboard != null)
                dashboard.MainContent.Content = new FilmsView();
        }
    }
}
