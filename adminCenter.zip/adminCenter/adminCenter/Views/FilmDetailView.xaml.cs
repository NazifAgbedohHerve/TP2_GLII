﻿using System.Windows;
using System.Windows.Controls;
using adminCenter.Models;

namespace adminCenter.Views
{
    public partial class FilmDetailView : UserControl
    {
        private readonly Film _film; // on garde une référence du film courant

        public FilmDetailView(Film film)
        {
            InitializeComponent();
            _film = film;
            DataContext = _film; // liaison des propriétés du film au XAML
        }

        // 🔙 Retourne à la liste des films
        private void BtnRetour_Click(object sender, RoutedEventArgs e)
        {
            var dashboard = Window.GetWindow(this) as AdminDashboard;
            if (dashboard != null)
                dashboard.MainContent.Content = new FilmsView();
        }
        
    }
}